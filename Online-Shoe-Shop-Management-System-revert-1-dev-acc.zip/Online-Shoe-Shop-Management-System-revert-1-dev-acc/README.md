Các folder bên ngoài là phần dùng chung giữa các trang 
- css : mn css vào file style.css (đặt tên theo cấu trúc đã được chia từ trước)
- js : chứa các file bootstrap.js
  
Với từng trang, mn tự tạo folder riêng để làm, thêm các file dùng riêng theo cấu trúc
- html 
- js : chứa các file js xử lí sự kiện của trang
- img : chứa các hình ảnh có trong trang
  
Về boostrap, mình sẽ link tới server thay vì down về máy

Trước mắt khi mn làm cứ tạo 2 thẻ div trống cho header và footer, khi nào mình làm xong 2 phần đó thì mn cop sang 
